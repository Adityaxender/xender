# BlackBerry 10 In-App-Browser Plugin

The in app browser functionality is entirely contained within common js. There is no native implementation required.
To install this plugin, follow the [Command-line Interface Guide](http://cordova.apache.org/docs/en/edge/guide_cli_index.md.html#The%20Command-line%20Interface).

If you are not using the Cordova Command-line Interface, follow [Using Plugman to Manage Plugins](http://cordova.apache.org/docs/en/edge/guide_plugin_ref_plugman.md.html).
./cordova-plugin-battery-status/README.md
./cordova-plugin-camera/README.md
./cordova-plugin-console/README.md
./cordova-plugin-contacts/README.md
./cordova-plugin-device/README.md
./cordova-plugin-device-motion/README.md
./cordova-plugin-device-orientation/README.md
./cordova-plugin-device-orientation/src/blackberry10/README.md
./cordova-plugin-file/README.md
./cordova-plugin-file-transfer/README.md
./cordova-plugin-geolocation/README.md
./cordova-plugin-globalization/README.md
./cordova-plugin-inappbrowser/README.md
./cordova-plugin-inappbrowser/src/blackberry10/README.md
./cordova-plugin-media/README.md
./cordova-plugin-media-capture/README.md
./cordova-plugin-network-information/README.md
./cordova-plugin-splashscreen/README.md
./cordova-plugin-vibration/README.md
